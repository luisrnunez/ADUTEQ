from django.db import models
from Periodo.models import Periodo
# Create your models here.
