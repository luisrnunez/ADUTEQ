from django.apps import AppConfig


class PagosproveedorConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'PagosProveedor'
