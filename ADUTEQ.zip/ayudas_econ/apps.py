from django.apps import AppConfig


class AyudasEconConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ayudas_econ'
