from django.apps import AppConfig


class PeriodoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Periodo'
